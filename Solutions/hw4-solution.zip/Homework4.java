package cse41321.homework.homework4;

import cse41321.containers.Stack;

/**
 * Demonstrates adding large numbers.
 *
 * Program output:
 *  592 + 3784 = 4376
 *  999 + 1 = 1000
 *  11111111111111111111 + 99999999999999999999 = 111111111111111111110
 *  12345678901234567890 + 987654321987654321 = 13333333223222222211
 *  111112222233333444445555566666777778888 +
 *      9999888877776666555544443333222211110000 =
 *      10111001100009999999989998899888988888888
 */
public class Homework4 {
    public static void main(String[] args) {
        addLargeNumbers(
                "592",
                "3784");
        addLargeNumbers(
                "999",
                "1");
        addLargeNumbers(
                "11111111111111111111",
                "99999999999999999999");
        addLargeNumbers(
                "12345678901234567890",
                "987654321987654321");
        addLargeNumbers(
                "111112222233333444445555566666777778888",
                "9999888877776666555544443333222211110000");
    }

    private static void addLargeNumbers(String number1, String number2) {

        System.out.printf("%s + %s = ", number1, number2);

        // Add digits together
        final Stack<Integer> num1Stack = pushDigitsOntoStack(number1);
        final Stack<Integer> num2Stack = pushDigitsOntoStack(number2);
        final Stack<Integer> resultStack = new Stack<>();
        int result = 0;
        while (!num1Stack.isEmpty() || !num2Stack.isEmpty()) {
            if (!num1Stack.isEmpty()) {
                result += num1Stack.pop();
            }
            if (!num2Stack.isEmpty()) {
                result += num2Stack.pop();
            }
            resultStack.push(result % 10);
            result /= 10;
        }

        // Carry the final 1
        if (result != 0) {
            resultStack.push(1);
        }

        // Print result
        while (!resultStack.isEmpty()) {
            System.out.print(resultStack.pop());
        }
        System.out.println();
    }

    private static Stack<Integer> pushDigitsOntoStack(String number) {
        Stack<Integer> numberStack = new Stack<>();
        for (char digit : number.toCharArray()) {
            numberStack.push(Integer.parseInt(String.valueOf(digit)));
        }
        return numberStack;
    }
}
