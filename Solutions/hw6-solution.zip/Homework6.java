package cse41321.homework.homework6;

import cse41321.containers.BinaryTree;

/**
 * Demonstrates tree algorithms.
 *
 * Program output:
 *  countLeaves(tree1) -> 3
 *  countLeaves(tree2) -> 5
 *  countNonLeaves(tree1) -> 6
 *  countNonLeaves(tree2) -> 4
 *  getHeight(tree1) -> 5
 *  getHeight(tree2) -> 4
 *  printPreOrder(tree1) -> 1 2 4 7 3 5 6 8 9
 *  printPreOrder(tree2) -> 6 4 2 1 3 5 8 7 9
 *  printInOrder(tree1) -> 7 4 2 1 5 3 6 8 9
 *  printInOrder(tree2) -> 1 2 3 4 5 6 7 8 9
 *  printPostOrder(tree1) -> 7 4 2 5 9 8 6 3 1
 *  printPostOrder(tree2) -> 1 3 2 5 4 7 9 8 6
 *  removeLeaves(tree1) -> 1 2 4 3 6 8
 *  removeLeaves(tree2) -> 6 4 2 8
 */
public class Homework6 {
    public static void main(String[] args) {
        // countLeaves
        System.out.printf("countLeaves(tree1) -> %d\n", countLeaves(buildTree1()));
        System.out.printf("countLeaves(tree2) -> %d\n", countLeaves(buildTree2()));

        // countNonLeaves
        System.out.printf("countNonLeaves(tree1) -> %d\n", countNonLeaves(buildTree1()));
        System.out.printf("countNonLeaves(tree2) -> %d\n", countNonLeaves(buildTree2()));

        // getHeight
        System.out.printf("getHeight(tree1) -> %d\n", getHeight(buildTree1()));
        System.out.printf("getHeight(tree2) -> %d\n", getHeight(buildTree2()));

        // printPreOrder
        System.out.print("printPreOrder(tree1) -> ");
        printPreOrder(buildTree1());
        System.out.print("printPreOrder(tree2) -> ");
        printPreOrder(buildTree2());

        // printInOrder
        System.out.print("printInOrder(tree1) -> ");
        printInOrder(buildTree1());
        System.out.print("printInOrder(tree2) -> ");
        printInOrder(buildTree2());

        // printPostOrder
        System.out.print("printPostOrder(tree1) -> ");
        printPostOrder(buildTree1());
        System.out.print("printPostOrder(tree2) -> ");
        printPostOrder(buildTree2());

        // removeLeaves
        System.out.print("removeLeaves(tree1) -> ");
        BinaryTree<Integer> tree1 = buildTree1();
        removeLeaves(tree1);
        printPreOrder(tree1);
        System.out.print("removeLeaves(tree2) -> ");
        BinaryTree<Integer> tree2 = buildTree2();
        removeLeaves(tree2);
        printPreOrder(tree2);
    }

    /**
     * Return tree:
     *            1
     *           / \
     *          2   3
     *         /   / \
     *        4   5   6
     *       /         \
     *      7           8
     *                   \
     *                    9
     */
    private static BinaryTree<Integer> buildTree1() {
        BinaryTree<Integer> tree = new BinaryTree<>();
        tree.insertRoot(1);
        tree.getRoot().insertLeft(2);
        tree.getRoot().insertRight(3);
        tree.getRoot().getLeft().insertLeft(4);
        tree.getRoot().getRight().insertLeft(5);
        tree.getRoot().getRight().insertRight(6);
        tree.getRoot().getLeft().getLeft().insertLeft(7);
        tree.getRoot().getRight().getRight().insertRight(8);
        tree.getRoot().getRight().getRight().getRight().insertRight(9);
        return tree;
    }

    /**
     * Return tree:
     *            1
     *           / \
     *          2   3
     *         /   / \
     *        4   5   6
     *       /         \
     *      7           8
     *                   \
     *                    9
     */
    private static BinaryTree<Integer> buildTree2() {
        BinaryTree<Integer> tree = new BinaryTree<>();
        tree.insertRoot(6);
        tree.getRoot().insertLeft(4);
        tree.getRoot().insertRight(8);
        tree.getRoot().getLeft().insertLeft(2);
        tree.getRoot().getLeft().insertRight(5);
        tree.getRoot().getRight().insertLeft(7);
        tree.getRoot().getRight().insertRight(9);
        tree.getRoot().getLeft().getLeft().insertLeft(1);
        tree.getRoot().getLeft().getLeft().insertRight(3);
        return tree;
    }

    private static int countLeaves(BinaryTree<Integer> tree) {
        return doCountLeaves(tree.getRoot());
    }

    private static int doCountLeaves(BinaryTree<Integer>.Node node) {
        if (node == null) {
            return 0;
        }
        if (node.isLeaf()) {
            return 1;
        }
        return doCountLeaves(node.getLeft()) + doCountLeaves(node.getRight());
    }

    private static int countNonLeaves(BinaryTree<Integer> tree) {
        return tree.getSize() - doCountLeaves(tree.getRoot());
    }

    private static int getHeight(BinaryTree<Integer> tree) {
        return doGetHeight(tree.getRoot());
    }

    private static int doGetHeight(BinaryTree<Integer>.Node node) {
        if (node == null) {
            return 0;
        }
        if (node.isLeaf()) {
            return 1;
        }
        return 1 + Math.max(doGetHeight(node.getLeft()), doGetHeight(node.getRight()));
    }

    private static void printPreOrder(BinaryTree<Integer> tree) {
        doPrintPreOrder(tree.getRoot());
        System.out.println();
    }

    private static void doPrintPreOrder(BinaryTree<Integer>.Node node) {
        if (node == null) {
            return;
        }
        System.out.printf("%d ", node.getData());
        doPrintPreOrder(node.getLeft());
        doPrintPreOrder(node.getRight());
    }

    private static void printInOrder(BinaryTree<Integer> tree) {
        printInOrder(tree.getRoot());
        System.out.println();
    }

    private static void printInOrder(BinaryTree<Integer>.Node node) {
        if (node == null) {
            return;
        }
        printInOrder(node.getLeft());
        System.out.printf("%d ", node.getData());
        printInOrder(node.getRight());
    }

    private static void printPostOrder(BinaryTree<Integer> tree) {
        printPostOrder(tree.getRoot());
        System.out.println();
    }

    private static void printPostOrder(BinaryTree<Integer>.Node node) {
        if (node == null) {
            return;
        }
        printPostOrder(node.getLeft());
        printPostOrder(node.getRight());
        System.out.printf("%d ", node.getData());
    }

    private static void removeLeaves(BinaryTree<Integer> tree) {
        doRemoveLeaves(tree.getRoot());
    }

    private static void doRemoveLeaves(BinaryTree<Integer>.Node node) {
        if (node == null) {
            return;
        }
        if (node.getLeft() != null && node.getLeft().isLeaf()) {
            node.removeLeft();
        }
        if (node.getRight() != null && node.getRight().isLeaf()) {
            node.removeRight();
        }
        doRemoveLeaves(node.getLeft());
        doRemoveLeaves(node.getRight());
    }
}
