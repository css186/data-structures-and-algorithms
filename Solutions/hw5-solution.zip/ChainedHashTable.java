// ChainedHashTable.java
package cse41321.homework.homework5;

import cse41321.containers.KeyValuePair;
import cse41321.containers.SinglyLinkedList;
import cse41321.exceptions.DuplicateKeyException;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ChainedHashTable<K, V> {
    // Table of buckets
    private SinglyLinkedList<KeyValuePair<K, V>>[] table;

    private int size;
    private double maxLoadFactor;
    private double resizeMultiplier;

    public ChainedHashTable() {
        this(997, .5, 2.0);  // A prime number of buckets
    }

    @SuppressWarnings("unchecked")
    public ChainedHashTable(
            int buckets,
            double maxLoadFactor,
            double resizeMultiplier) {

        // Create table of empty buckets
        table = new SinglyLinkedList[buckets];
        for (int i = 0; i < table.length; ++i) {
            table[i] = new SinglyLinkedList<KeyValuePair<K, V>>();
        }

        this.maxLoadFactor = maxLoadFactor;
        this.resizeMultiplier = resizeMultiplier;

        size = 0;
    }

    public int getBuckets() {
        return table.length;
    }

    public int getSize() {
        return size;
    }

    public double getLoadFactor() {
        return (double)size / table.length;
    }

    public double getMaxLoadFactor() {
        return maxLoadFactor;
    }

    public double getResizeMultiplier() {
        return resizeMultiplier;
    }

    public boolean isEmpty() {
        return getSize() == 0;
    }

    /**
     * Big-O now periodically O(n) when growth required due to all elements
     * requiring re-insertion. However, since growth occurs less frequently
     * as more resizes occur, the overall Big-O of insert is O(n / log n).
     */
    public void insert(K key, V value) throws
            IllegalArgumentException,
            DuplicateKeyException {
        growIfNecessary();

        if (key == null) {
            throw new IllegalArgumentException("key must not be null");
        }
        if (contains(key)) {
            throw new DuplicateKeyException();
        }

        getBucket(key).insertHead(new KeyValuePair<K, V>(key, value));
        ++size;
    }

    @SuppressWarnings("unchecked")
    private void growIfNecessary() {
        // Return if inserting one more element won't exceed maxLoadFactor
        if ((double)(size + 1) / getBuckets() <= maxLoadFactor) {
            return;
        }

        // Save reference to old table
        SinglyLinkedList<KeyValuePair<K, V>>[] oldTable = table;

        // Create new table resizeMultiplier bigger
        table = new SinglyLinkedList[
                (int)Math.round(oldTable.length * resizeMultiplier)];
        for (int i = 0; i < table.length; ++i) {
            table[i] = new SinglyLinkedList<KeyValuePair<K, V>>();
        }
        size = 0;

        // Re-insert existing elements
        for (SinglyLinkedList<KeyValuePair<K, V>> bucket : oldTable) {
            for (SinglyLinkedList<KeyValuePair<K, V>>.Element
                 element = bucket.getHead();
                 element != null;
                 element = element.getNext()) {
                insert(element.getData().getKey(),
                        element.getData().getValue());
            }
        }
    }

    public V remove(K key) throws
            IllegalArgumentException,
            NoSuchElementException {
        if (key == null) {
            throw new IllegalArgumentException("key must not be null");
        }

        // If empty bucket
        SinglyLinkedList<KeyValuePair<K, V>> bucket = getBucket(key);
        if (bucket.isEmpty()) {
            throw new NoSuchElementException();
        }

        // If at head of bucket
        SinglyLinkedList<KeyValuePair<K, V>>.Element elem = bucket.getHead();
        if (key.equals(elem.getData().getKey())) {
            --size;
            return bucket.removeHead().getValue();
        }

        // Scan rest of bucket
        SinglyLinkedList<KeyValuePair<K, V>>.Element prev = elem;
        elem = elem.getNext();
        while (elem != null) {
            if (key.equals(elem.getData().getKey())) {
                --size;
                return bucket.removeAfter(prev).getValue();
            }
            prev = elem;
            elem = elem.getNext();
        }

        throw new NoSuchElementException();
    }

    public V lookup(K key) throws
            IllegalArgumentException,
            NoSuchElementException {
        if (key == null) {
            throw new IllegalArgumentException("key must not be null");
        }

        // Scan bucket for key
        SinglyLinkedList<KeyValuePair<K, V>>.Element elem =
                getBucket(key).getHead();
        while (elem != null) {
            if (key.equals(elem.getData().getKey())) {
                return elem.getData().getValue();
            }
            elem = elem.getNext();
        }

        throw new NoSuchElementException();
    }

    public boolean contains(K key) {
        try {
            lookup(key);
        } catch (IllegalArgumentException ex) {
            return false;
        } catch (NoSuchElementException ex) {
            return false;
        }

        return true;
    }

    /**
     * Multiplication method used since after growth the number of buckets
     * won't be prime.
     */
    private SinglyLinkedList<KeyValuePair<K, V>> getBucket(K key) {
        // Multiplication method
        return table[(int)Math.floor(table.length * (key.hashCode() * .618) % 1)];
    }

    private class KeysIterator implements Iterator<K> {
        private int remaining;  // Number of keys remaining to iterate
        private int bucket;     // Bucket we're iterating
        private SinglyLinkedList<KeyValuePair<K, V>>.Element elem;
                                // Position in bucket we're iterating

        public KeysIterator() {
            remaining = ChainedHashTable.this.size;
            bucket = 0;
            elem = ChainedHashTable.this.table[bucket].getHead();
        }

        public boolean hasNext() {
            return remaining > 0;
        }

        public K next() {
            if (hasNext()) {
                // If we've hit end of bucket, move to next non-empty bucket
                while (elem == null) {
                    elem = ChainedHashTable.this.table[++bucket].getHead();
                }

                // Get key
                K key = elem.getData().getKey();

                // Move to next element and decrement entries remaining
                elem = elem.getNext();
                --remaining;

                return key;
            } else {
                throw new NoSuchElementException();
            }
        }
    }

    public Iterable<K> keys() {
        return new Iterable<K>() {
            public Iterator<K> iterator() {
                return new KeysIterator();
            }
        };
    }
}
