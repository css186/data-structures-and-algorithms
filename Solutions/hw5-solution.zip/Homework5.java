package cse41321.homework.homework5;

/**
 * Demonstrates an auto-growing chained hash table.
 *
 * Program output:
 *  buckets 5, elements 1, lf 0.200000, max lf 0.500000, resize mult 2.000000
 *  buckets 5, elements 2, lf 0.400000, max lf 0.500000, resize mult 2.000000
 *  buckets 10, elements 3, lf 0.300000, max lf 0.500000, resize mult 2.000000
 *  1 expected, found? true
 *  4 not expected, found? false
 */
public class Homework5 {
    public static void main(String[] args) {
        ChainedHashTable<Integer, Double> table =
                new ChainedHashTable<>(5, 0.5, 2.0);

        // Insert enough values to cause growth
        insertIntoTable(table, 1, 5.0);
        insertIntoTable(table, 2, 10.0);
        insertIntoTable(table, 3, 15.0);

        // Verify key that was inserted is still there
        System.out.printf("%d expected, found? %b\n", 1, table.contains(1));

        // Verify key never inserted is not there
        System.out.printf("%d not expected, found? %b\n", 4, table.contains(4));
    }

    private static <K, V> void insertIntoTable(
            ChainedHashTable<K, V> table,
            K key,
            V value) {
        table.insert(key, value);
        printHashTableInfo(table);
    }

    private static <K, V> void printHashTableInfo(ChainedHashTable<K, V> table) {
        System.out.printf(
                "buckets %d, elements %d, lf %f, max lf %f, resize mult %f\n",
                table.getBuckets(),
                table.getSize(),
                table.getLoadFactor(),
                table.getMaxLoadFactor(),
                table.getResizeMultiplier());
    }
}
